package org.sid.Application.Interfaces;

import org.sid.Application.Entities.Pakage;

public interface PackageInterface {
	
     public void ruleOfDimensions(Pakage pakage);
}
