package org.sid.Application;

import org.sid.Application.Model.ShipmentModel;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroserviceShipmentApplication{
    
	
	public static void main(String[] args) {
		SpringApplication.run(MicroserviceShipmentApplication.class, args);
		//isslam OK ok ok
	}

}
