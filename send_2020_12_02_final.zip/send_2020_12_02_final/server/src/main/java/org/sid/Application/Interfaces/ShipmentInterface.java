package org.sid.Application.Interfaces;

public interface ShipmentInterface {
	
	public double capAmountCalculator(double declaredValue, double capRate);
	public String ourTrackingNumberGenerator();

}
